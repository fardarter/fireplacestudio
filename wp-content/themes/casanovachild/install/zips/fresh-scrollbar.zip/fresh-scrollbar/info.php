<?php

$info = array();
$info['plugin-name'] = 'fresh-scrollbar';
$info['plugin-version'] = '1.0.0';