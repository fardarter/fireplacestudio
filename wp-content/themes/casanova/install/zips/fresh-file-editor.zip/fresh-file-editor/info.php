<?php

$info = array();
$info['plugin-name'] = 'fresh-file-editor';
$info['plugin-version'] = '1.0.1';