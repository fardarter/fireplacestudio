<?php

$info = array();
$info['plugin-name'] = 'casanova-core';
$info['plugin-version'] = '1.0.2';